#
# TABLE STRUCTURE FOR: buat_surat
#

DROP TABLE IF EXISTS buat_surat;

CREATE TABLE `buat_surat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_surat` varchar(255) NOT NULL,
  `nama1` varchar(255) NOT NULL,
  `nama2` varchar(255) NOT NULL,
  `nip1` varchar(255) NOT NULL,
  `nip2` varchar(255) NOT NULL,
  `pangkat1` varchar(255) NOT NULL,
  `jabatan1` varchar(255) NOT NULL,
  `pangkat2` varchar(255) NOT NULL,
  `jabatan2` varchar(255) NOT NULL,
  `tugas` varchar(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `waktu` varchar(255) NOT NULL,
  `lokasi` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `plh` varchar(255) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO buat_surat (`id`, `no_surat`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `plh`, `keterangan`) VALUES ('7', '', 'Agus Sudaryatno, S.Kom, MM', 'Anang Ariane, S.Si, M.Sc', '196101201980031001 ', '198706112008121001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'PMG Pertama', 'Menghadiri Apel Penutupan Posko Angkutan Udara Natal 2018 dan Tahun Baru 2019', 'Stasiun Klimatologi Kelas IV Mlati', '08.00 WIB s.d. selesai', 'Lapangan NDB PT. Angkasa Pura I (Persero)', '2019-01-10', '', '');
INSERT INTO buat_surat (`id`, `no_surat`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `plh`, `keterangan`) VALUES ('8', '', 'Agus Sudaryatno, S.Kom, MM', 'Desy Rumayanti Setyo, A.Md', '196101201980031001 ', '198312142008122001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'Pengadministrasian Umum', '', 'Stasiun Klimatologi Kelas IV Mlati', '', '', '0000-00-00', '', 'telah melaksanakan Magang/PKL (Praktek Kerja Lapangan) Pengelolaan Arsip Dinamis (Arsip Aktif) di Kantor Stasiun Klimatologi Kelas IV Mlati dan Arsip Inaktif di Kantor Stasiun Geofisika Kelas I Yogyakarta.');
INSERT INTO buat_surat (`id`, `no_surat`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `plh`, `keterangan`) VALUES ('9', '', 'Agus Sudaryatno, S.Kom, MM', 'Desy Rumayanti Setyo, A.Md', '196101201980031001 ', '198312142008122001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'Pengadministrasian Umum', 'Menghadiri Apel Penutupan Posko Angkutan Udara Natal 2018 dan Tahun Baru 2019', 'Stasiun Klimatologi Kelas IV Mlati', '08.00 WIB s.d. selesai', 'Lapangan NDB PT. Angkasa Pura I (Persero)', '2019-01-25', '', 'coba aja');
INSERT INTO buat_surat (`id`, `no_surat`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `plh`, `keterangan`) VALUES ('10', '', 'Agus Sudaryatno, S.Kom, MM', 'Anang Ariane, S.Si, M.Sc', '196101201980031001 ', '198706112008121001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'Pengadministrasian Umum', 'Menghadiri Apel Penutupan Posko Angkutan Udara Natal 2018 dan Tahun Baru 2019', 'Stasiun Klimatologi Kelas IV Mlati', '08.00 WIB s.d. selesai', 'Lapangan NDB PT. Angkasa Pura I (Persero)', '2019-01-11', '', 'mencoba');
INSERT INTO buat_surat (`id`, `no_surat`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `plh`, `keterangan`) VALUES ('11', 'KP.003/939/SMN/XII/2018', 'Agus Sudaryatno, S.Kom, MM', 'Desy Rumayanti Setyo, A.Md', '196101201980031001 ', '198312142008122001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'Pengadministrasian Umum', 'Menghadiri Apel Penutupan Posko Angkutan Udara Natal 2018 dan Tahun Baru 2019', 'Stasiun Klimatologi Kelas IV Mlati', '08.00 WIB s.d. selesai', 'Lapangan NDB PT. Angkasa Pura I (Persero)', '2019-01-10', 'PLH. Kepala,', '');


#
# TABLE STRUCTURE FOR: gambar
#

DROP TABLE IF EXISTS gambar;

CREATE TABLE `gambar` (
  `id_gambar` int(11) NOT NULL AUTO_INCREMENT,
  `gambar` varchar(255) NOT NULL,
  `surat_id` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  PRIMARY KEY (`id_gambar`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO gambar (`id_gambar`, `gambar`, `surat_id`, `nama`, `tgl_surat`) VALUES ('1', '1.jpg', '1', '', '0000-00-00');


#
# TABLE STRUCTURE FOR: login
#

DROP TABLE IF EXISTS login;

CREATE TABLE `login` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator');
INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('15', 'bmkg', '123', 'bmkg');
INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('16', 'haya', '123456', 'Hayabusa');


#
# TABLE STRUCTURE FOR: tb_surat_keluar
#

DROP TABLE IF EXISTS tb_surat_keluar;

CREATE TABLE `tb_surat_keluar` (
  `surat_id` int(11) NOT NULL AUTO_INCREMENT,
  `no_agenda` varchar(255) NOT NULL,
  `kode_arsip` varchar(255) NOT NULL,
  `kode_arsip2` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `no_surat` varchar(255) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `perihal` text NOT NULL,
  `asli_copy` varchar(255) NOT NULL,
  `keterangan` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  PRIMARY KEY (`surat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('6', '', '', '', '0000-00-00', '', '', '', 'surat asli', '    ', '6.jpg');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('7', '', '', '', '2019-01-11', '', '', '', 'surat asli', '  ', '7.png');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('8', '', '', '', '2019-01-05', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('9', '', '', '', '0000-00-00', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('10', '', '', '', '0000-00-00', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('11', '1', 'PL.203', '', '2019-01-11', '100', 'yoguakarta', 'bimbingan', 'surat asli', 'www', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('12', '', '', '', '0000-00-00', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('13', '', '', '', '0000-00-00', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('14', '001', 'KP.019', '', '2019-01-12', '1234567', 'yoguakarta', 'bimbingan', 'surat asli', 'ssss', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('15', 'w', '', '', '0000-00-00', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('16', 'w', '', '', '0000-00-00', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('17', '', '', '', '0000-00-00', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('18', '', '', '', '0000-00-00', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('19', '', '', '', '2019-01-03', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('20', '', '', '', '2019-01-03', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('21', '', '', '', '0000-00-00', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('22', '11', 'KU.105', '', '2019-01-10', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('23', '', '', '', '2019-01-27', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('24', '', '', '', '2019-01-03', '', '', '', 'surat asli', '', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('25', '', '', '', '2019-02-05', '', '', '', 'surat asli', '', '');


#
# TABLE STRUCTURE FOR: tb_surat_masuk
#

DROP TABLE IF EXISTS tb_surat_masuk;

CREATE TABLE `tb_surat_masuk` (
  `surat_id` int(11) NOT NULL AUTO_INCREMENT,
  `no_agenda` varchar(255) NOT NULL,
  `tgl_terima` date NOT NULL,
  `kode_arsip` varchar(255) NOT NULL,
  `no_surat` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `pengirim` varchar(25) NOT NULL,
  `perihal` text NOT NULL,
  `lampiran` varchar(255) NOT NULL,
  `sifat_surat` varchar(255) NOT NULL,
  `penjabat_disposisi` varchar(255) NOT NULL,
  `disposisi` varchar(255) NOT NULL,
  `asli_copy` varchar(255) NOT NULL,
  `informasi_disposisi` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  PRIMARY KEY (`surat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO tb_surat_masuk (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('18', '001', '2019-01-03', 'PR.203', '100', '2019-01-18', 'Johar', 'bimbingan', 'satu bendel', 'Biasa', 'dekan', '0', 'surat asli', 'ee', '');
INSERT INTO tb_surat_masuk (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('19', '', '2019-03-04', '', '', '0000-00-00', '', '', '', 'Biasa', '', '0', 'surat asli', '', '');
INSERT INTO tb_surat_masuk (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('20', '', '2019-02-25', '', '', '0000-00-00', '', '', '', 'Biasa', '', '0', 'surat asli', '', '');
INSERT INTO tb_surat_masuk (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('21', '', '2019-01-03', '', '', '0000-00-00', '', '', '', 'Biasa', '', '0', 'surat asli', '', '');
INSERT INTO tb_surat_masuk (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('22', '', '2019-04-04', '', '', '0000-00-00', '', '', '', 'Biasa', '', '0', 'surat asli', '', '');


